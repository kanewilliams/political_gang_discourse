import os
from os import listdir
from os.path import isfile, join

DONTINCLUDE = [r'C:\Users\thebu\Documents\7th Year (MADS)\DIGI405 - Texts, Discourses and Data\Assessment\Data',
			   r'C:\Users\thebu\Documents\7th Year (MADS)\DIGI405 - Texts, Discourses and Data\Assessment\Data\.ipynb_checkpoints']

testdir = ['']
current_directory = os.getcwd()
directory_items = os.walk(current_directory)

def count_words_in_file(filepath):
	number_of_words = 0
	with open(filepath,'r', encoding="UTF-8") as file:
		data = file.read()
		lines = data.split()
		for word in lines:        
			number_of_words += 1
	return number_of_words

folders = []
for item in directory_items:
	folders.append(item[0])

files = {} # DICTIONARY: {Green_Directory: List_of_green_txt_files}
for folder in folders:
	files[folder] = [f for f in listdir(folder) if isfile(join(folder, f))]


for k, v in files.items():
	if k not in DONTINCLUDE:
		total_word_count = 0
		for file in v:
			#print("LOOKING IN: ", join(k, file))
			total_word_count += count_words_in_file(join(k, file))
			#print(f"TOTAL WORD COUNT: {total_word_count} \n")

		print(f"FOLDER: {k}, \n \
		        FIRST ITEMS: {v[0:5]}\n \
		        COUNT: {len(v)}\n \
		        WORD COUNT: {total_word_count}\n")
